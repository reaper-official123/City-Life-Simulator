require('dotenv').config();
require('./bot').startBot();
