const { Client, GatewayIntentBits, Collection } = require('discord.js');
const connectDB = require('./database/mongo');

async function startBot(){
  const client = new Client({intents:[GatewayIntentBits.Guilds]});
  client.commands = new Collection();
  await connectDB();
  client.login(process.env.TOKEN);
}

module.exports={startBot};
